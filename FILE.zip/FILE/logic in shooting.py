import pygame
pygame.init()
size=width,height=1000,600
screen=pygame.display.set_mode((size))
player=pygame.Rect(width/2,height-50-10,50,50)
bullet=pygame.Rect(520,height-70,10,10)
shoot=False
run=True
while run:
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    key=pygame.key.get_pressed()
    if key[pygame.K_SPACE]:
        shoot=True
    if shoot:
        bullet.y-=1

    if bullet.y==0:
        bullet.y=height-70
        shoot=False

    pygame.draw.rect(screen,((20,200,0)),bullet)
    pygame.draw.rect(screen,((255,0,0)),player,10)
    pygame.display.update()
pygame.quit()
