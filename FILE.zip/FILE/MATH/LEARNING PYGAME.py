import pygame 
pygame.init()
#screen
SCREEN_SIZE=WIDTH,HEIGHT=800,600
#background
win=pygame.display.set_mode((SCREEN_SIZE))
backgroundscale=pygame.transform.smoothscale(
    pygame.image.load("land.jpg"),(800,700))
backgroundrotate=pygame.transform.rotate(backgroundscale,360)
#player
x=400
xene=500
y=417
width=40
height=60
vel=5
left=False
right=False
playerleft=pygame.image.load("player.png")
playerright=pygame.image.load("player right.png")
def enemy():
    win.blit(playerright,(xene,y))
    
    pygame.display.update()            
    
def redrawgamewindow():
    win.fill(white)
    win.blit(backgroundscale,(0,0))
    if left:
        if left:
            win.blit(playerleft,(x,y))
        else:
            win.blit(playerleft,(x,y))
    elif right:
        if right:
            win.blit(playerright,(x,y))
        else:
            win.blit(playerright,(x,y))
    else:
        win.blit(playerleft,(x,y))
        
    pygame.display.update()
#color
white=(255,255,255)
running=True
while running:
    pygame.time.delay(20)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            running=False
    key=pygame.key.get_pressed()
    if key[pygame.K_LEFT]:
        if x <= 0:
            x=700
        x-=vel
        left=True
        right=False
    elif key[pygame.K_RIGHT]and x < 800- width - width- vel:
        x+=vel
        left=False
        right=True



    
    if xene >=0:
        xene+=vel
    else:
        xene-=vel
    
    redrawgamewindow()
    enemy()
pygame.quit()
    




























