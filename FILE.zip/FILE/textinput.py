import pygame
pygame.init()
size=width,height=(800,600)
screen=pygame.display.set_mode()
text=""
win=pygame.font.SysFont("arial",100)
blink=0
mx,my=50,50
run=True
while run:
    blink+=1
    mou=pygame.mouse.get_pressed()
    msg=win.render(text,1,(255,255,255))
    msgr=msg.get_rect()
    if mou[0]:
        mx,my=pygame.mouse.get_pos()
        msgr.x=mx
        msgr.y=my
    msgr.x=mx
    msgr.y=my
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.KEYDOWN:
            text+=event.unicode.upper()
            
    key=pygame.key.get_pressed()
    if key[pygame.K_BACKSPACE]:
        if len(text)>0:
            text=text[:-1]
        
    pygame.draw.rect(screen,((255,0,0)),(msgr.x-10,msgr.y-5,msgr.x+500,msgr.height+10))
    x,y=msgr.topright
    if blink>=100:
        pygame.draw.rect(screen,((255,255,255)),(x,y,2,msgr.height))
    if blink==200:
        blink=0
    
    screen.blit(msg,msgr)
    pygame.display.update()
pygame.quit()
