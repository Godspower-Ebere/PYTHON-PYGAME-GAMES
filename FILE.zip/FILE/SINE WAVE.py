import pygame
import math
import random

pygame.init()
size=width,height=(1200,800)
screen=pygame.display.set_mode(size)
def sin():
    t=pygame.time.get_ticks()%1000
    print(t)
    x=t
    y=math.sin(t/50)*100+200
    pygame.draw.circle(screen,(r,g,b),(x,y),10)

run=True
while run:
    screen.fill((0,0,0))
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    click=pygame.mouse.get_pressed()
    if click[0]:
        sin()
    pygame.display.update()

pygame.quit()
