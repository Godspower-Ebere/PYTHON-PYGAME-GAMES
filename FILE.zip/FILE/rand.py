import pygame
import random
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
x=[]
y=[]
w=[]
h=[]
many=10
for i in range(many):
    x.append(random.randint(0,950))
    y.append(random.randint(-800,0))
    w.append(50)
    h.append(100)
    

run=True
while run:
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    for i in range(many):
        pygame.draw.rect(screen,((255,0,0)),(x[i],y[i],w[i],h[i]))
        y[i]+=0.2
    pygame.display.update()
pygame.quit()
