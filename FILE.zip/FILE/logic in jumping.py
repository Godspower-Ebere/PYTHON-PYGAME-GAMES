import time

jump=False
run=True
y=500
vel=5
while run:
    if jump is False:
        jump=True
    if jump==True:
        y-=vel
        print(y)

        vel-=0.1
        print(vel)

        if vel <= -5:
            vel=5
            jump=False                                                     
            run=False
