import pygame
pygame.init()
size=width,height=(800,600)
screen=pygame.display.set_mode(size)
img=pygame.image.load("bomb.gif")
screen.fill((255,255,255))
win=pygame.font.SysFont("arial",20)
msg=win.render("CLEANER",1,(255,255,255))
msgr=msg.get_rect()

color=(255,0,0)
out=2
run=True
while run:
    msgr.x=100
    msgr.y=100
    mouse=pygame.mouse.get_pos()
    click=pygame.mouse.get_pressed()
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.MOUSEBUTTONUP:
            color=(255,0,0)
    if click[0]:
        if msgr.collidepoint(event.pos):
            color=(255,255,255)
            msgr.x=mouse[0]
            msgr.y=mouse[1]
            pygame.draw.rect(screen,color,msgr,out)
            out=1
        pygame.draw.circle(screen,(color),(mouse[0],mouse[1]),5)
    
    pygame.draw.rect(screen,color,msgr,out)
    screen.blit(msg,(msgr.x,msgr.y))
    pygame.display.update()
pygame.quit()
