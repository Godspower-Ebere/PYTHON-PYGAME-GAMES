import pygame
import random
import time
from pygame.locals import *
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
x=200
y=700
w=100
h=50
r=Rect(x,y,w,h)
class bullet:
	def __init__(self,x,y,w,h):
		self.x=x
		self.y=y
		self.w=w
		self.h=h
		self.br=Rect(x,y,w,h)
	def gun(self,screen):
		b=Rect(self.x,self.y,self.w,self.h)
		pygame.draw.rect(screen,((0,0,255)),b)
shot=[]
now=time.time()
s=time.time()
ex=[]
ey=[]
ew=20
eh=20
for i in range (ew):
	ex.append(random.randint(0,1000))
	ey.append(random.randint(-800,0))
clock=pygame.time.Clock()
run=True
while run:
        
	t=time.time()-now
	screen.fill((255,255,255))
	for event in pygame.event.get():
		if event.type==pygame.QUIT:
			run=False
	clock.tick(60)
	for i in range(ew):
		e=Rect(ex[i],ey[i],ew,eh)
		if e.colliderect(r):
			run=False
		pygame.draw.rect(screen,((0,255,0)),e)
		ey[i]+=5
		if ey[i]>850:
			ey[i]=random.randint(-800,0)
		for shots in shot:
			if e.colliderect(shots.x,shots.y,30,30):
				shot.pop(shot.index(shots))
				ey[i]=random.randint(-800,0)
	for shots in shot:
		if shots.y> -50:
			shots.y-=5
		else:
			shot.pop(shot.index(shots))
		shots.gun(screen)
	click=pygame.mouse.get_pressed()
	pos=pygame.mouse.get_pos()
	mx,my=pos
	if click[0]:
		if r.x>mx-50:
			r.x-=3
		else:
			r.x+=3
		if r.y>my-30:
			r.y-=3
		else:
			r.y+=3
		if t >=0.5:
			shot.append(bullet(r.x+30,r.y,30,30))
			now=time.time()
			t=time.time()-now
	pygame.draw.rect(screen,((255,0,0)),r)
	pygame.display.update()
pygame.quit()
