import pygame
import random
pygame.init()

size=w,h=(800,800)
scr=pygame.display.set_mode(size)
run=True

x=[]
y=[]
width=[]
height=[]
r=[]
g=[]
b=[]
num=500
for i in range(num):
    x.append(random.randint(2,w))
    y.append(random.randint(2,h))
    width.append(10)
    height.append(10)
    r.append(random.randint(0,255))
    g.append(random.randint(0,255))
    b.append(random.randint(0,255))

clock=pygame.time.Clock()

while run:
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    for i in range(num):
        
        pygame.draw.rect(scr,((r[i],  g[i],b[i])),(x[i],y[i],width[i]  ,height[i]))
        x[i]+=1
        if x[i]>=w:
            x[i]=0
            y[i]+=100
        if y[i]>=h:
            y[i]=random.randint(0,100)
    clock.tick(60)
    pygame.display.update()
pygame.quit()
