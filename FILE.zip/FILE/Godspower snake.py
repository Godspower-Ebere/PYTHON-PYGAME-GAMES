import pygame
from pygame.locals import *
pygame.init()
size=width,height=(800,800)
screen=pygame.display.set_mode(size,pygame.SCALED)
left=False
right=False
up=False
down=False
x=width/2
y=height/2
big=20
snake=[]
snakelen=5
score=0

long=0.6
ax=(width)/2/2
ay=(height)/2/2
aleft=False
aright=False
aup=False
adown=False
p=Rect(ax,ay,big,big)
rect=[]
run=True
while run:
        score+=1
        if score>= 10:
                snakelen+=1
                score=0
        screen.fill((255,255,255))
        for event in pygame.event.get():
                if event.type==pygame.QUIT:
                        run=False
        
        if y>ay:
                up=True
                down=True
                left=False
                right=False
                y-=long
        if ay>y:
                down=True
                left=False
                right=False
                up=False
                y+=long
        if x>ax:
                left=True
                right=False
                up=False
                down=False
                x-=long
        if ax>x:
                right=True
                up=False
                down=False
                left=False
                x+=long
                
        if up==True:
                pass
                
        if down==True:
                pass
                
        elif left==True:
                pass
                
        elif right==True:
                pass

        if y>=height:
                y=height-20
            
        if x>=width:
                x=width-20
           
        if x<=0:
                x=20
         
        if y<=0:
                y=20
         
                
        
        head=[]
        head.append(x)
        head.append(y)
        snake.append(head)
        if len(snake)>=snakelen:
              del snake[0]  
        k=pygame.key.get_pressed()
        if k[pygame.K_LEFT]:
                ax-=1
        if k[pygame.K_RIGHT]:
                ax+=1
        if k[pygame.K_UP]:
                ay-=1
        if k[pygame.K_DOWN]:
                ay+=1
                
        pygame.draw.rect(screen,((0,255,0)),p)
        
        m=pygame.mouse.get_pressed()
        p=pygame.mouse.get_pos()
  

        for i in snake:
                e=Rect(i[0],i[1],15,15)
                rect.append(e)
                pygame.draw.circle(screen,((255,0,0)),(i[0],i[1]),big-5)
                for c in rect:
                        if c.colliderect(p):
                                run=False
                

        pygame.display.update()
pygame.quit()
