import pygame
pygame.init()

size=width,height=(800,800)
screen=pygame.display.set_mode(size)
white=(255,255,255)
myfont=pygame.font.SysFont("impact",50)
font=myfont.render("START GAME",1,(0,0,0))
fontrect=font.get_rect()
fontrect.center=width/2,height/2
start=pygame.image.load("start.png")
startrect=start.get_rect()
startrect.center=200,height/2
end=pygame.image.load("end.png")
endrect=start.get_rect()
endrect.center=600,height/2


run=True
while run:
    screen.fill(white)
    key=pygame.key.get_pressed()
  
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        if event.type==pygame.MOUSEBUTTONDOWN:
            pass
    mousepos=pygame.mouse.get_pos()
    mouse=pygame.mouse.get_pressed()
    if mouse[0]:
        if startrect.collidepoint(mousepos):
            print("click")
        if endrect.collidepoint(mousepos):
            print("")



     
    screen.blit(start,(startrect))
    screen.blit(end,(endrect))
    pygame.display.update()
pygame.quit()
