import pygame
import random
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
x=width
y=random.randint(-200,0)-50
y2=random.randint(400,600)+50
def rect():
    global x    
    pygame.draw.rect(screen,((255,0,0)),(x,y,70,400))
    pygame.draw.rect(screen,((255,0,0)),(x,y2,70,400))
    x-=1
run=True
while run:
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    rect()
    if x<=0-70:
        y=random.randint(-200,0)-50
        y2=random.randint(400,600)+50
        rect()
        x=width
    pygame.display.update()
pygame.quit()
