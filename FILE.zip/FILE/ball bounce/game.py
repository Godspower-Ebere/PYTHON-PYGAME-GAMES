import pygame
from pygame.locals import *
pygame.init()
run=True

#sizes
size=width,height=(1000,700)
screen=pygame.display.set_mode(size)
screen.fill((0,255,0))
#colors
green=(0,255,0)
red=(255,0,0)
#ball
ball=pygame.image.load("ball.png")
rect=ball.get_rect()
rect.center=width/2,height/2
speed=[1,1]
while run:
    for event in pygame.event.get():
        if event.type==QUIT:
            run=False
    rect=rect.move(speed)
    if rect.left < 0 or rect.right > width:
        speed[0]=-speed[0]
    if rect.top <0 or rect.bottom > height:
        speed[1]=-speed[1]
    screen.blit(ball,rect)  
    pygame.draw.rect(screen,red,rect,1)
         
    pygame.display.update()
pygame.quit()
quit()
 
