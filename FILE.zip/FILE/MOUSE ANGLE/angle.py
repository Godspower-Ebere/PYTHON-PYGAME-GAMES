import pygame
import math
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)

turretimg=pygame.transform.smoothscale(pygame.transform.flip(pygame.image.load("turret.png"),False,True),(100,200)).convert_alpha()
bul=pygame.image.load("bullet.png")

x,y=width/2,height/2

bullet=[]
speed=10
run=True
c=0
clock=pygame.time.Clock()
while run:
    clock.tick(60)
    screen.fill((255,255,255))
    
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    mx,my=pygame.mouse.get_pos()
    dx=mx-x
    dy=-(my-y)
    angle=math.atan2(dy,dx)
    print(angle)
    deg=math.degrees(angle)
    turret=pygame.transform.rotate(turretimg,deg-90)
    
    bulangle=math.atan2(my-y,mx-x)
    bulx=math.cos(bulangle)
    buly=math.sin(bulangle)

    bullimg=pygame.transform.rotate(bul,deg-90)
    mpress=pygame.mouse.get_pressed()
    c+=1
    if c>=20:
        bullet.append([x,y,bulx,buly,bullimg])
        c=0
    for i in bullet:
        i[0]+=i[2]*speed
        i[1]+=i[3]*speed
        screen.blit(i[4],(i[0],i[1]))


    screen.blit(turret,(x-int(turret.get_width()/2),y-int(turret.get_height())))
    pygame.display.update()
    
pygame.quit()
