import pygame
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
wcount=0
tilesize=32
man1=pygame.transform.scale(pygame.image.load("asset/man.png"),(70,70))
man2=pygame.transform.flip(pygame.transform.scale(pygame.image.load("asset/man.png"),(70,70)),True,False)
water=[
        pygame.image.load("asset/water/water1.png"),
        pygame.image.load("asset/water/water2.png"),
        pygame.image.load("asset/water/water3.png"),
        pygame.image.load("asset/water/water4.png"),
        pygame.image.load("asset/water/water5.png"),
        pygame.image.load("asset/water/water6.png"),
        pygame.image.load("asset/water/water7.png"),
        pygame.image.load("asset/water/water8.png"),
        pygame.image.load("asset/water/water9.png"),
        pygame.image.load("asset/water/water10.png")
        ]

bg=pygame.transform.scale(pygame.image.load("asset/bg/sky.png"),(1000,800))
waterb=pygame.image.load("asset/water/waterblock.png")
watercount=0
manblit=man1
stop=True
manr=manblit.get_rect()
manr.x=850
manr.y=height-70
cury=[]
jump=False      
jumpc=10
vel=1
world=[
        "11111111111111111111111111111111",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1.............................11",
        "1...........fggggggs..........11",
        "1.............................11",
        "1.........................fggg11",
        "1ggggggs......................11",
        "1.............................11",
        "1.............................11",
        "1...........fggggggs..........11",
        "1.............................11",
        "1gggggs.......................11",
        "1.....................fggggggg11",
        "1.............................11",
        "1.............................11",
        "1......fggggwwgggggs..........11",
        "1.....f1111eeeeee111ggs.......11",
        "1....f11111eeeeeeee1111ggs....11",
        "11111111111eeeeeeee1111111111111"
        ]



wall=pygame.transform.scale(pygame.image.load("asset/wall.png"),(tilesize,tilesize))
wallr=wall.get_rect()

first=pygame.image.load("asset/1.png")
firstr=first.get_rect()



second=pygame.image.load("asset/2.png")
secondr=second.get_rect()

grass=pygame.image.load("asset/grass.png")
grassr=grass.get_rect()


run=True
clock=pygame.time.Clock()
while run:
        screen.blit(bg,(0,0))
        tilel=[]
        watercount+=0.2
        if watercount>=10:
                watercount=0
        water1=water[int(watercount)]
##        manr.x=manx
##        manr.y=many
        clock.tick(60)
        for event in pygame.event.get():
                if event.type==pygame.QUIT:
                        run=False
         
        for x, row in enumerate(world):
                for y, column in enumerate(row):
                        wx=y*tilesize
                        wy=x*tilesize
                        

                        

                        

                        
                        if column=="1":
                                wallr.x,wallr.y=wx,wy
                                if wallr.colliderect(manr.x,manr.y+10,32,32):
                                        if jumpc>=0:
                                                manr.top=wallr.bottom
                                        if jumpc==10:
                                                manr.bottom=wallr.top
                                else:
                                        pass
##                                        manr.y+=1
                                screen.blit(wall,(wx,wy))
                                
                        if column=="f":
                                firstr.x,firstr.y=wx,wy
                                screen.blit(first,(wx,wy))
                                
                        if column=="s":
                                secondr.x,secondr.y=wx,wy
                                screen.blit(second,(wx,wy))
                                
                        if column=="g":
                                grassr.x,grassr.y=wx,wy
                                if grassr.colliderect(manr.x,manr.y+10,32,32):
                                        if jumpc>=0:
                                                manr.y=grassr.y+32
                                        if jumpc==10:
                                                manr.y=grassr.y-70
                                screen.blit(grass,(wx,wy))
                                
                        if column=="w":
                                screen.blit(water1,(wx,wy))

                                
                        if column=="e":
                                screen.blit(waterb,(wx,wy))
##        manr.y+=1 
        pygame.draw.rect(screen,((0,0,0)),(manr.x,manr.y,70,70),2)
        key=pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
                manblit=man2
                manr.x-=5
        if key[pygame.K_RIGHT]:
                manr.x+=5
                manblit=man1
        if key[pygame.K_SPACE]:
                jump=True
        if jump:
##                cury.append(many)
                manr.y-=jumpc
                jumpc-=1
                if jumpc ==-10:
                        stop=False
                if stop==False:
                        jumpc=int(10)
##                        many=cury[0]
##                        cury=[]
                        jump=False
                        stop=True
        if manr.x>=width-100:
                manr.x=width-100
        if manr.x<=25:
                manr.x=25
        screen.blit(manblit,manr)
        pygame.display.update()
pygame.quit()















































