import pygame
from pygame.locals import *
pygame.init()
run=True

#sizes
size=width,height=(1000,700)
screen=pygame.display.set_mode(size)
screen.fill((255,255,255))
#colors
green=(0,255,0)
red=(255,0,0)

start=(0,0)
size=(0,0)
drawing=False


while run:
    for event in pygame.event.get():
        if event.type==QUIT:
            run=False
        elif event.type==MOUSEBUTTONDOWN:
            start=event.pos
            print(start)
            size=0,0
            drawing=True
        elif event.type == MOUSEBUTTONUP:
            end=event.pos
            size=end[0]-start[0],end[1]-start[1]
            print(size)
            drawing=False
            
    pygame.draw.rect(screen,red,(start,size),2)      
    pygame.display.update()
pygame.quit()
quit()
 
