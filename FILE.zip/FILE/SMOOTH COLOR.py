import pygame 
import random
pygame.init()
size=width,height=(500,500)
screen=pygame.display.set_mode(size)
rrand=random.randint(0,100)
grand=random.randint(0,100)
brand=random.randint(0,100)
r=rrand
b=brand
g=grand
run=True
plus=False
plus1=False
plus2=False
minus=False
minus1=False
minus2=False
s=1
max=250
while run:
	if r ==rrand:
		plus=True
		minus=False
	if g==grand:
		plus1=True
		minus1=False
	if b==brand:
		plus2=True
		minus2=False
		
	if plus:
		r+=s
	if plus1:
		g+=s
	if plus2:
		b+=s
	if r==max:
		plus=False
		minus=True
	if g==max:
		plus1=False
		minus1=True
	if b==max:
		plus2=False
		minus2=True
	if minus:
		r-=s
	if minus1:
		g-=s
	if minus2:
		b-=s
	
	screen.fill((255,255,255))
	pygame.draw.rect(screen,((r,g,0)),(20,100,400,50),0,0,50,0,50,50)
	for event in pygame.event.get():
		if event.type==pygame.QUIT:
			run=False	
	pygame.display.update()
pygame.quit()
