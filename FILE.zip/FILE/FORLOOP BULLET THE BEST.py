import pygame
import time
pygame.init()
size=width,height=(500,800)
screen=pygame.display.set_mode(size)
bullet=[]
now=time.time()
px,py=300,700

run=True
while run:
	times=time.time()-now
	screen.fill((255,255,255))
	for event in pygame.event.get():
		if event.type==pygame.QUIT:
			run=False
		
	click =pygame.mouse.get_pressed()
	if click[0]:
		if times>=0.8:
			bullet.append([px,py])
			now=time.time()
			times=time.time()-now
	pygame.draw.rect(screen,((255,0,0)),(px,py,20,20))
	for i in bullet:
		i[1]-=2
		pygame.draw.rect(screen,((255,255,0)),(px,i[1],10,10))
		if i[1]<200:
			bullet.pop(0)
	pygame.display.update()
	
pygame.quit()