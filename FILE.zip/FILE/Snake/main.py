import pygame
pygame.init()

size=width,height=(800,800)
screen=pygame.display.set_mode(size)
play=pygame.Rect(width/2,height/2,30,30)
vel=0
vely=0
lenght=10
run=True
long=[]
count=0
head=pygame.image.load("head.png")
headu=pygame.image.load("head.png")
headd=pygame.transform.flip(head,True,True)
headl=pygame.transform.rotate(head,90)
headr=pygame.transform.rotate(head,270)
clock=pygame.time.Clock()
while run:
    count+=1
    clock.tick(60)
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    play.x+=vel
    play.y+=vely
    long.append([play.x,play.y])
    key=pygame.key.get_pressed()
    if key[pygame.K_RIGHT] and play.x+play.width+10<=width:
        vel=5
        vely=0
    if key[pygame.K_LEFT] and play.x>0:
        vel=-5
        vely=0
    if key[pygame.K_UP] and play.y>0:
        vely=-5
        vel=0
    if key[pygame.K_DOWN] and play.y+play.height<height:
        vely=5
        vel=0
    for i in long:
                    pygame.draw.rect(screen,((255,0,0)),(i[0],i[1],30,30))
    if len(long)>=lenght:
        long.pop(0)
    if count>=50:
        count=0
        lenght+=1
    upos=long[-1][0],long[-1][1]-32
    dpos=long[-1][0],long[-1][1]+32
    rpos=long[-1][0]+32,long[-1][1]
    lpos=long[-1][0]-32,long[-1][1]
    pos=upos
    if vel>=5:
        pos=rpos
        head=headr
    if vel<=-5:
        pos=lpos
        head=headl
    if vely>=5:
        head=headd
        pos=dpos
    if vely<=-5:
        pos=upos
        head=headu
    
    
    pygame.draw.rect(screen,((255,0,0)),play)
    screen.blit(head,(pos))
    pygame.display.update()
pygame.quit()
