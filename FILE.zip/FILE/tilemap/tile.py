import pygame
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
tilesize=40

maping=[
    "BBBBBBBBBBBBBBBBBBBBBBBBB",
    "e.......................e",
    "e.....BBBBB.............e",
    "e....BBBBBBB............e",
    "e...BBBBBBBBB...........e",
    "e...BBB.B.BBB...........e",
    "e...BBBBBBBBB...........e",
    "e...BBBBBBBBB...........e",
    "e...BBBB.BBBB...........e",
    "e...BBBB.BBBB...........e",
    "e...BBBBBBBBB...........e",
    "e.......................e",
    "e.........BBBBBB........e",
    "e....BBBB...............e",
    "e........BBBBBBBB.......e",
    "e........B..............e",
    "e........B..............e",
    "e....BBB..BBBBBBBB......e",
    "e.......................e",
    "eeeeeeeeeeeeeeeeeeeeeeeee"
    ]
w=tilesize
h=tilesize
block=pygame.transform.scale(pygame.image.load("platform.png"),(w,h))
grass=pygame.transform.scale(pygame.image.load("GRASS.png"),(w,h))
F=pygame.transform.scale(pygame.image.load("FIRST EDGES.png"),(w,h))
S=pygame.transform.scale(pygame.image.load("SECOND EDGES.png"),(w,h))
W=pygame.transform.scale(pygame.image.load("WALL1.png"),(w,h))

run=True
while run:
    screen.fill((255,255,255))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
    for x, row in enumerate(maping):
        for y, column in enumerate(row):
            wx=y*tilesize
            wy=x*tilesize
            if column=="B":
                screen.blit(block,(wx,wy))
            if column=="b":
                screen.blit(grass,(wx,wy))
            if column=="c":
                screen.blit(F,(wx,wy))
            if column=="d":
                screen.blit(S,(wx,wy))
            if column=="e":
                screen.blit(W,(wx,wy))
    pygame.display.update()
pygame.quit()
