import pygame
#from pygame.locals import *
pygame.init()

size=width,height=(1000,600)
screen=pygame.display.set_mode(size)
pygame.display.set_caption("white color".upper())

#colors
red=(255,0,0)
green=(0,255,0)
blue=(0,0,255)
yellow=(255,255,0)
cyan=(0,255,255)
background=(255,255,255)
black=(0,0,0)
screen.fill(background)

ball=pygame.image.load("ball.png")
ball.convert()
rect=ball.get_rect()
rect.center=width/2,height/2

moving=False
running=True
while running:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            running=False
        elif event.type==pygame.MOUSEBUTTONDOWN:
            if rect.collidepoint(event.pos):
                moving=True
        elif event.type==pygame.MOUSEBUTTONUP:
            moving=False
        elif event.type==pygame.MOUSEMOTION and moving:
            rect.move_ip(event.rel)
        
       
        pygame.draw.rect(screen,(yellow),rect,2)
        screen.blit(ball,rect)
        pygame.display.update()
pygame.quit()
