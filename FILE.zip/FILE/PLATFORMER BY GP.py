import pygame
import math
pygame.init()



def main():
    size=width,height=(1000,800)
    screen=pygame.display.set_mode(size)
    quit=False
    global playermomentum
    gamemap=[
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"],
        ["0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0","1","1","1","1","0","0"]
        ]
    def hitlist(playerrect,tilerect):
        hitlist=[]
        for i in tilerect:
            if playerrect.colliderect(i):
                hitlist.append(i)
        return hitlist
    def collision(playerrect,tilerect,move):
        global playermomentum
        ### FOR X AXIS #####
        playerrect.x+=move[0]
        bottom=False
        collision=hitlist(playerrect,tilerect)
        for i in collision:
            if move[0]>0:
                playerrect.right=i.left
            if move[0]<0:
                playerrect.left=i.right
        ### FOR Y AXIS #####
        playerrect.y+=move[1]
        collision=hitlist(playerrect,tilerect)
        for i in collision:
            if move[1]>0:
                playerrect.bottom=i.top
                bottom=True
            if move[1]<0:
                playermomentum+=2
                playerrect.top=i.bottom
                
        return playerrect,bottom
    playermomentum=0
    tilerect=pygame.Rect(0,0,40,20)
    playerrect=pygame.Rect(100,100,20,50)
    
    clock=pygame.time.Clock()
    jump=False
    bottom=False
    left,right=False,False
    bulx=0
    buly=height/2
    dx,dy=0,0
    bullet=[]
    mx,my=bulx,buly
    wait=0
    while not quit:
        tilelist=[]
        screen.fill((150,150,150))
        radians=math.atan2(playerrect.y-buly,playerrect.x-bulx)
        dx=math.cos(radians)
        dy=math.sin(radians)

        wait+=1
        if wait>=30:
            bullet.append([mx,my,dx,dy])
            wait=0
        for i in bullet:
            brect=pygame.Rect(i[0],i[1],10,10)
            i[0]+=i[2]*10
            i[1]+=i[3]*10
            pygame.draw.rect(screen,((255,0,0)),(i[0],i[1],10,10))
            for tile in tilelist:
                if brect.colliderect(tile):
                    print("yes")
                    bullet.pop(bullet.index(i))
        clock.tick(60)
        
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                quit=True
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_SPACE:
                    jump=True
        if jump and bottom:
            playermomentum=-30
        else:
            jump=False
        
        
        y=0
        for row in gamemap:
            x=0
            for column in row:
                if column=="1":
                    tilerect.x=x*tilerect.width
                    tilerect.y=y*tilerect.width
                    pygame.draw.rect(screen,((0,0,0)),tilerect)
                    tilelist.append(pygame.Rect(x*tilerect.width,y*tilerect.width,tilerect.width,tilerect.height))
                x+=1
            y+=1
        playermovement=[0,0]
        key=pygame.key.get_pressed()
        if key[pygame.K_r]:
            main()
        if key[pygame.K_RIGHT]:
            playermovement[0]=5
            right=True
        else:
            left=False
        if key[pygame.K_LEFT]:
            playermovement[0]=-5
            left=True
        else:
            left=False
        playermovement[1]+=playermomentum
        playermomentum+=2
        if playermomentum>10:
            playermomentum=10
        playerrect,bottom=collision(playerrect,tilelist,playermovement)
        playerrect2=pygame.Rect(playerrect.x,playerrect.y-20,playerrect.w,playerrect.h)
        if bottom==False:
            pygame.draw.rect(screen,((255,255,0)),playerrect2)
        pygame.draw.rect(screen,((255,255,0)),playerrect)
        pygame.display.update()
    pygame.quit()

main()










































