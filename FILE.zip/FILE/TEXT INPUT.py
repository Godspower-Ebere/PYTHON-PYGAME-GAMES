import pygame
import time


pygame.init()
size=width,height=(800,500)
screen=pygame.display.set_mode(size)

run=True
text=""
win=pygame.font.SysFont("Tahoma",30)

blink=0
remove=0
once=1
mouse=pygame.mouse.get_pressed()
press=False
ok=0
while run:
	mg=win.render(text,1,(255,0,255))
	remove+=1
	msg=mg.get_rect()
	msg.x=50
	msg.y=100
	x,y=msg.topright
	w=5
	h=msg.height
	screen.fill((255,255,255))
	
	for event in pygame.event.get():
		if event.type==pygame.QUIT:
			run=False
		if event.type==pygame.KEYDOWN:
			if event.key==pygame.K_BACKSPACE:
				if len(text) >0:
					text=text[:-1]
			else:
				text+=event.unicode.upper()
			
	if mouse:
		press=True
	pygame.draw.rect(screen,(100,100,100),(msg.x,msg.y,msg.x+200,msg.height))
	screen.blit(mg,(msg))
	if len(text)>14:
		text=text[:-1]
			
	if press==True:
		blink+=1
		if blink>=100:
			pygame.draw.rect(screen,((0,0,0)),(x,y,w,			h))
		if blink>=200:
			blink=0
	screen.blit(mg,(100,400))
	pygame.display.update()
pygame.quit()