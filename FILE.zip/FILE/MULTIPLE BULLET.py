import pygame
import time
from pygame.locals import *
pygame.init()

size=width,height=(450,800)
screen=pygame.display.set_mode(size)
x=width/2
y=height-100
w=30
h=50
bx=x+16
by=y
bullet=[]
rect=Rect(bx,by,10,10)
r=Rect(x,y,w,h)
now= time.time()
color=(0,0,255)
yellow=(255,255,0)
blue=color
run=True
class bullets:
	def __init__(self,x,y,w,h):
		self.x=x
		self.y=y
		self.w=w
		self.h=h
	"""def gun(self,screen):
		pygame.draw.rect(screen,((200,200,0)),(self.x,self.y,self.w,self.h))"""
while run:
	snow=time.time()-now
	screen.fill((255,255,255))
	for event in pygame.event.get():
		if event.type==pygame.QUIT:
			run=False
	for bull in bullet:
		pygame.draw.rect(screen,(color),(width/2,bull.y+20,10,10))
		if r.colliderect(width/2,bull.y,10,10):
			color=yellow
		else:
			color=blue
		if bull.y >= -20:
			bull.y-=1
		else:
			 bullet.pop(bullet.index(bull))
	click=pygame.mouse.get_pressed()
	if click[0]:
		if snow >=0.5:
			now=time.time()
			snow=int(time.time()-now)
			bullet.append(bullets(bx,by,10,10))
	pygame.draw.rect(screen,((255,0,0)),(x,y,w,h))
	pygame.display.update()
pygame.quit()