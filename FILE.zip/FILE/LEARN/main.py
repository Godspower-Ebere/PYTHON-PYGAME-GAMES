import pygame
import math
pygame.init()

size=width,height=(1000,800)
screen=pygame.display.set_mode(size)
godot=pygame.image.load("icon.png")
pw=godot.get_width()
x,y=width/2,height/2

vel=5
clock=pygame.time.Clock()
quit=False
while not quit:
    clock.tick(60)
    screen.fill((70,70,70))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            quit=True
    key=pygame.key.get_pressed()
    if key[pygame.K_RIGHT]:
        x+=vel
    if key[pygame.K_LEFT]:
        x-=vel
    
    screen.blit(godot,(x-pw/2,y))
    pygame.display.update()
pygame.quit()
