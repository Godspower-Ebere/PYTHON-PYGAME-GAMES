##import pygame
##import sys
##import math
##pygame.init()
##
### Set up display dimensions
##width, height = 800, 600
##screen = pygame.display.set_mode((width, height))
##
### Set the title of the window
##pygame.display.set_caption("Rotate Image")
##
### Load the image you want to rotate
##image = pygame.image.load('icon.png')
##
##angle = 0
##rotation_speed = 2
##
##def rotate_image(image, angle):
##    # Get the original dimensions of the image
##    orig_rect = image.get_rect()
##    
##    # Create a new image with a transparent background
##    rotated_image = pygame.Surface(orig_rect.size, pygame.SRCALPHA)
##    
##    # Rotate the image around its center
##    rotated_image.blit(image, orig_rect)
##    rotated_image = pygame.transform.rotate(rotated_image, angle)
##    
##    # Get the rect of the rotated image and adjust its center
##    rotated_rect = rotated_image.get_rect(center=orig_rect.center)
##    
##    return rotated_image, rotated_rect
##
##
##running = True
##clock = pygame.time.Clock()
##
##while running:
##    for event in pygame.event.get():
##        if event.type == pygame.QUIT:
##            running = False
##
##    # Check for key presses
##    keys = pygame.key.get_pressed()
##    if keys[pygame.K_LEFT]:
##        angle += rotation_speed
##    if keys[pygame.K_RIGHT]:
##        angle -= rotation_speed
##
##    # Clear the screen
##    screen.fill((255, 255, 255))
##
##    # Rotate and blit the image onto the screen
##    rotated_image, rotated_rect = rotate_image(image, angle)
##    screen.blit(rotated_image, rotated_rect.topleft)
##
##    # Update the display
##    pygame.display.flip()
##
##    clock.tick(60)
##
##pygame.quit()
##sys.exit()
import pygame
import sys
import math

pygame.init()

width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Move on Rotated Axis")

image = pygame.image.load('icon.png').convert_alpha()

angle = 0
rotation_speed = 2
x, y = width // 2, height // 2  # Initial position
speed = 5  # Movement speed

def rotate_image(image, angle):
    orig_rect = image.get_rect()
    rotated_image = pygame.Surface(orig_rect.size, pygame.SRCALPHA)
    rotated_image.blit(image, orig_rect)
    rotated_image = pygame.transform.rotate(rotated_image, angle)
    rotated_rect = rotated_image.get_rect(center=orig_rect.center)
    return rotated_image, rotated_rect

running = True
clock = pygame.time.Clock()

while running:
    print(angle)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        angle += rotation_speed
    if keys[pygame.K_RIGHT]:
        angle -= rotation_speed
    
    # Calculate the direction vector for movement
    direction_x = math.cos(angle)
    direction_y = math.sin(angle)

    print(direction_x,direction_y)
    # Update position based on arrow key presses
    if keys[pygame.K_UP]:
        x +=direction_x
        y +=direction_y

    screen.fill((255, 255, 255))

    rotated_image, rotated_rect = rotate_image(image, angle)

    # Adjust the position based on the rotated image
    rotated_rect.topleft = (x - rotated_rect.width / 2, y - rotated_rect.height / 2)

    screen.blit(rotated_image, rotated_rect.topleft)
    if angle>=360:
        angle=360
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()

