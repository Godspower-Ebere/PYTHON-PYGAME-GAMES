import pygame
from pygame.locals import *
from time import sleep
pygame.init()

size=width,height=(800,300)
screen=pygame.display.set_mode(size)
screen.fill((255,255,255))
run=True

pygame.mixer.music.load("music.mp3")
pygame.mixer.music.play(-1,0,0)

player=pygame.image.load("R1.png")
playerrect=player.get_rect()
playerrect.center=width/4,height/2+height/4-30

enemy=pygame.image.load("L11.png")
enemyrect=enemy.get_rect()
enemyrect.center=width/1.1,height/2+height/4-24

myfont=pygame.font.SysFont(None,100)
font=myfont.render("GAME OVER",2,(255,255,0))

background=pygame.image.load("background.jpg")
FPS=60
vel=5
clock=pygame.time.Clock()
while run:
    clock.tick(FPS)
    playerblit=screen.blit(player,playerrect)
    print(playerblit[0])
    for event in pygame.event.get():
        if event.type==QUIT:
            run=False
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT:
                playerrect=playerrect.move([-5,0])
            if event.key==pygame.K_RIGHT:
                playerrect=playerrect.move([5,0])
               
    enemyrect=enemyrect.move([-1,0])
    if enemyrect[0]==-50:
        enemyrect[0]=width
    if playerrect[0]==-20:
        playerrect=playerrect.move([5,0])
    if playerrect[0]==enemyrect[0]:
        clock.tick(1)
        screen.blit(font,(width/2,0))
    
            


    screen.blit(background,(0,0))
    pygame.draw.rect(screen,((0,0,0)),(0,height/2+height/4,width,height/4))
    screen.blit(player,playerrect)
    screen.blit(enemy,enemyrect)
    if playerrect[0]+10==enemyrect[0]:
        break
        







        
    pygame.display.update()

pygame.quit()




























