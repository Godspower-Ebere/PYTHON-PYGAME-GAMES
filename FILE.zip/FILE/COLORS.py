import pygame
import random
pygame.init()
size=width,height=(1000,800)
screen=pygame.display.set_mode(size)

clock=pygame.time.Clock()
run=True
while run:
    clock.tick(1)
    r,g,b=random.randint(0,255),random.randint(0,255),random.randint(0,255)
    screen.fill((r,g,b))
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False

##    pygame.time.delay(40)
    pygame.display.update()
pygame.quit()
